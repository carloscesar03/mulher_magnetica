
export default function Summary() {
  return (
    <section className="py-20 lg:py-24 px-6 bg-zinc-950 text-white text-center border-t border-zinc-800">
        <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl font-black mb-10 text-rose-500 uppercase tracking-widest">RESUMINDO</h2>
            
            <p className="text-xl font-medium mb-6 text-gray-300">Você pode fechar essa página e continuar:</p>
            
            <div className="space-y-3 text-lg font-medium text-gray-400 mb-10 text-left max-w-md mx-auto">
                <p className="flex items-center gap-2"><span className="text-rose-500 font-bold">❌</span> Sendo tratada como "estepe" (lembrada só quando ele quer).</p>
                <p className="flex items-center gap-2"><span className="text-rose-500 font-bold">❌</span> Aceitando desculpas esfarrapadas para sumiços.</p>
                <p className="flex items-center gap-2"><span className="text-rose-500 font-bold">❌</span> Sentindo que você nunca é o suficiente.</p>
            </div>
            
            <p className="text-2xl font-bold text-white mb-12 uppercase leading-snug">
                OU você pode investir o preço de um lanche para <span className="text-rose-500">assumir o controle da sua vida amorosa hoje.</span>
            </p>
            
            <div className="bg-zinc-900 p-8 rounded-2xl border border-zinc-800 mb-12">
                <p className="text-xl font-medium leading-relaxed">
                    Por <span className="text-rose-500 font-bold text-2xl">R$ 9,00</span>, você descobre ajustes que podem mudar completamente sua experiência nos relacionamentos.
                </p>
            </div>
            
            <p className="text-3xl font-black mb-8 uppercase tracking-tight">A decisão está nas suas mãos.</p>
            <p className="text-xl text-gray-300 font-light mb-10">Clique agora e comece hoje.</p>
            
            <a href="https://payfast.greenn.com.br/redirect/275403" className="btn-pulse-green inline-block w-full sm:w-auto text-center bg-green-600 hover:bg-green-700 text-white font-black py-5 px-12 rounded-lg transition-colors text-lg uppercase tracking-widest shadow-[0_0_20px_rgba(34,197,94,0.3)] mb-6">
                QUERO COMEÇAR AGORA
            </a>

            <div className="flex justify-center mt-2">
                <img src="https://i.postimg.cc/LsVHTKKJ/xxxcompra_Segura_vetor_branco1_1.png" alt="Segurança" loading="lazy" width="300" height="40" referrerPolicy="no-referrer" className="h-8 object-contain opacity-70" />
            </div>
        </div>
    </section>
  );
}
